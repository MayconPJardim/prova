# Prova prática — Tarefas 1 a 3

**Cerca de 55 minutos no computador.** Leia esta página inteira antes de começar.

---

## Como esta parte funciona

Ela **não mede se você sabe digitar código de cabeça** — isso foi a Tarefa 0, no papel. Aqui se
mede como você trabalha com código real e com as ferramentas do dia a dia, incluindo IA
(Inteligência Artificial).

> **Você não precisa digitar código.** Na Tarefa 2 a IA escreve o código; o seu trabalho é dizer
> o que quer, dar contexto, conferir o resultado e decidir. Pode editar à mão se quiser, mas
> ninguém espera isso de você.

| Tarefa | Tempo de referência | Editor | IA |
|---|---|---|---|
| **1 — Revisão de código** | 20 min | **VS Code** | **proibida** |
| **2 — Implementação** | 25 min | **Cursor** | **liberada e esperada** |
| **3 — Verificação escrita** | 10 min | papel + VS Code | **proibida** |

Os tempos são de referência. O avaliador avisa quando faltarem 5 minutos e anuncia a troca de
tarefa; pequenas extrapolações são toleradas e anotadas, não punidas.

### O que é "uso de IA"

**É uso de IA:** abrir chat, agente ou assistente de código de qualquer tipo — inclusive o
Cursor, o Copilot e qualquer site ou aplicativo de IA — e **colar código do projeto em qualquer
site ou serviço externo**.

**Não é uso de IA:** o resumo que o buscador mostra sozinho quando você pesquisa. Ainda assim,
nas Tarefas 1 e 3 consulte só a documentação oficial que está nos favoritos do navegador.

**Usar IA na Tarefa 1 ou na Tarefa 3 — se aparecer na gravação — zera a nota da tarefa em que
ocorreu.** Na Tarefa 2 a IA é liberada, mas **só pelo Cursor da sua estação**: não use conta ou
ferramenta pessoal.

### Combinados

- **Sua tela é gravada** durante as três tarefas. O avaliador orienta quando iniciar e parar.
- **Na Tarefa 2, use uma única conversa** do começo ao fim. Ao terminar, você exporta essa
  conversa para um arquivo `conversa.md` na pasta principal do projeto (o avaliador mostra como).
  Sem ela, a Tarefa 2 não é avaliada.
- **Você não precisa usar git.** Não é avaliado.
- Se algo do enunciado não estiver claro, **decida, siga em frente e anote a sua premissa**.
- O arquivo `RESPOSTAS.md` já está na pasta principal, com um modelo. É nele que você escreve.

---

## O cenário

O **Portal de Solicitação de Equipamentos** é o sistema interno em que os colaboradores pedem
equipamentos de TI do catálogo — notebook, monitor, headset. A equipe técnica aprova ou recusa
cada pedido e registra a entrega.

O sistema já existe e funciona. Foi escrito às pressas, com auxílio de IA, e entrou em uso
**sem nenhuma revisão**.

A pasta do projeto tem:

| Pasta ou arquivo | O que é |
|---|---|
| `REGRAS.md` | as regras de negócio — **é a especificação**: quando o código e ele discordarem, quem está certo é ele |
| `api/` | o servidor, em C# |
| `web/` | a tela (HTML, CSS e JavaScript) |
| `dados/` | o arquivo exportado pelo RH, usado pela ferramenta de exportação de e-mails |
| `RESPOSTAS.md` | onde você escreve as suas respostas |

### Como subir

O servidor já foi preparado e está no ar em `http://localhost:3000`. O seletor **"Entrar como"**
no topo troca o usuário — não há senha, e isso é uma simplificação proposital.

Se precisar (todos os comandos, **de dentro da pasta `api/`**):

| Para quê | Comando |
|---|---|
| compilar | `dotnet build` |
| recriar o banco do zero (apaga tudo e volta ao estado inicial) | `dotnet run --no-build -- seed` |
| subir o servidor | `dotnet run --no-build` |
| gerar a lista de e-mails do comunicado | `dotnet run --no-build -- exportar-emails` |

Para parar o servidor, use `Ctrl+C` no terminal em que ele está rodando. Depois de alterar código,
compile de novo antes de subir.

---

## Tarefa 1 — Revisão de código (20 minutos, VS Code, **sem IA**)

O código deste projeto foi gerado por IA e aprovado sem revisão.

**Encontre o que está errado.** O projeto tem três partes, e as três estão no escopo: o servidor
(`api/`), a tela (`web/`) e a ferramenta de exportação de e-mails. Não dizemos quantos problemas
existem.

Para cada achado, escreva em `RESPOSTAS.md` (o modelo já traz os campos):

- **onde** — arquivo e linha;
- **o que acontece de errado**, em uma frase;
- **como você provaria** — o clique, a URL ou o comando que expõe o problema;
- **qual regra do `REGRAS.md`** está sendo violada, se houver;
- **gravidade** — alta, média ou baixa, com uma frase de justificativa.

Não corrija nada nesta tarefa. Só aponte.

---

## Tarefa 2 — Implementação (25 minutos, Cursor, **com IA**, conversa gravada)

Quando o avaliador anunciar, abra o **Cursor** e trabalhe na mesma pasta. A coordenação da equipe
técnica mandou estes cinco pedidos. Implemente o que couber no tempo.

> 1. Toda decisão sobre uma solicitação precisa registrar **quem decidiu e quando**.
> 2. O colaborador pode reenviar uma solicitação recusada, com nova justificativa, desde que
>    respeite as mesmas regras de abertura de uma solicitação nova. Todas as tentativas e todas
>    as decisões precisam aparecer na tela.
> 3. A equipe técnica se compromete a decidir cada solicitação em até **8 horas úteis** —
>    segunda a sexta, das 8h às 18h, sem expediente em feriados. A tela deve mostrar o
>    prazo-limite de cada solicitação em aberto.
> 4. O colaborador pode cancelar sua solicitação a qualquer momento, **inclusive depois de
>    aprovada**.
> 5. Uma decisão registrada **nunca** pode ser alterada nem apagada.

Feriados a considerar: **12/10/2026, 02/11/2026, 15/11/2026, 20/11/2026 e 25/12/2026**.

Não é obrigatório entregar os cinco. É melhor poucos bem resolvidos do que todos pela metade —
mas registre em `RESPOSTAS.md` o que ficou de fora e por quê.

Se alguma decisão sua depender de algo que o enunciado não diz, **decida e anote a decisão** em
`RESPOSTAS.md`. Anotar a premissa vale ponto; adivinhar em silêncio, não.

Ao terminar, exporte a conversa para `conversa.md` e **avise o avaliador**.

---

## Tarefa 3 — Verificação escrita (10 minutos, papel, **sem IA**)

Você **pede a folha da Tarefa 3 ao avaliador** quando terminar a Tarefa 2 — ou ela é entregue
quando o tempo da Tarefa 2 acabar. Ao entregá-la, o avaliador **encerra o servidor e fecha o
Cursor**.

Você responde **no papel**, em cerca de 10 minutos, sobre o que implementou. Pode **ler o seu
código no VS Code**, mas **não pode executar o sistema nem usar IA**. As perguntas tratam do
prazo de decisão, de uma mudança no expediente e de dúvidas sobre o enunciado.

Não é prova de memória: ler o próprio código e refazer o raciocínio é permitido — é o que se
espera.

---

## O que entregar

- a pasta do projeto como ficou;
- o arquivo `RESPOSTAS.md` preenchido;
- o arquivo `conversa.md` com a conversa da Tarefa 2;
- a folha da Tarefa 3, ao avaliador.
