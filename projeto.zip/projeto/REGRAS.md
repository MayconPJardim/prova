# Regras do Portal de Solicitação de Equipamentos

Documento de referência da equipe técnica. É a especificação a que o sistema deve obedecer:
quando o código e este documento discordarem, quem está certo é o documento.

## Catálogo

1. Só se solicitam itens do catálogo de equipamentos.

## Solicitação

2. Qualquer colaborador abre uma solicitação para si, escolhendo um item do catálogo e
   escrevendo uma justificativa.
3. **Somente a equipe técnica** (papel `tecnico`) aprova ou recusa uma solicitação.
4. Solicitação aprovada é entregue pela equipe técnica, que registra a entrega no sistema.
   **Somente a equipe técnica** registra entrega.
5. Os equipamentos de solicitações **entregues** ficam sob responsabilidade do colaborador
   que as abriu.

## Limite de responsabilidade

6. O valor sob responsabilidade de um colaborador é a soma dos valores dos equipamentos
   entregues a ele.
7. **Colaborador com R$ 5.500,00 ou mais sob sua responsabilidade não pode abrir nova
   solicitação.**

## Busca

8. A lista de solicitações pode ser filtrada pelo nome do equipamento ou do colaborador.

## Comunicados de entrega

9. A lista de e-mails para comunicados de entrega é gerada a partir do arquivo exportado pelo
   RH (`dados/colaboradores-rh.json`) e inclui **somente** colaboradores **ativos** que
   **aceitaram receber comunicados**.

## Identificação do usuário

10. Não há senha nesta versão. O usuário é identificado pelo cabeçalho `X-Usuario-Id`, e a
    tela oferece um seletor "Entrar como". Isso é uma simplificação deliberada do exercício
    — não é um dos problemas que se procura.
