# Respostas

**Candidato nº:** ______

---

## Tarefa 1 — Revisão de código

Copie o bloco abaixo para cada achado

- **Onde:** linha 70
- **O que acontece de errado:** esta faltando = no >
- **Como provar:** com o usuario ana ribeiro que tem 5.500,00 é aceita uma solicitação
- **Regra violada:** regra 7
- **Gravidade:** media

- **Onde:** linha 64
- **O que acontece de errado:** soma em double, a boa pratica é usar decimal 
- **Como provar:**  arrendodamento do frontend
- **Regra violada:** na
- **Gravidade:** media

- **Onde:** 103
- **O que acontece de errado:** busca concatenada no SQL, possivel SQL Injection
- **Como provar:** codigo sql
- **Regra violada:** na
- **Gravidade:**alta

- **Onde:** linha 80
- **O que acontece de errado:** justificativa sem escape
- **Como provar:** no frontend
- **Regra violada:** no
- **Gravidade:** meida

- **Onde:** linha 20
- **O que acontece de errado:** exportação ignora consentimento 
- **Como provar:** No frontend
- **Regra violada:** Regra 9
- **Gravidade:** Grave

*(acrescente quantos achados forem necessários)*

---

## Tarefa 2 — Implementação

### O que implementei

*(liste os itens 1 a 5 que entregou, com uma frase para cada)*

### O que ficou de fora, e por quê

### Premissas e decisões

*(tudo o que o enunciado não dizia e você decidiu; e as dúvidas que teve ao ler)*
