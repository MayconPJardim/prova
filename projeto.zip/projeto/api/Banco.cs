using Microsoft.Data.Sqlite;

namespace Portal;

public static class Banco
{
    public static readonly string Arquivo =
        Path.GetFullPath(Path.Combine(Directory.GetCurrentDirectory(), "solicitacoes.db"));

    public static SqliteConnection Conectar()
    {
        var conexao = new SqliteConnection($"Data Source={Arquivo}");
        conexao.Open();
        using var comando = conexao.CreateCommand();
        comando.CommandText = "PRAGMA foreign_keys = ON";
        comando.ExecuteNonQuery();
        return conexao;
    }

    public static void CriarEsquema(SqliteConnection conexao, SqliteTransaction? transacao = null)
    {
        using var comando = conexao.CreateCommand();
        if (transacao is not null) comando.Transaction = transacao;
        comando.CommandText = """
            DROP TABLE IF EXISTS decisao;
            DROP TABLE IF EXISTS cancelamento;
            DROP TABLE IF EXISTS tentativa;
            DROP TABLE IF EXISTS solicitacao;
            DROP TABLE IF EXISTS equipamento;
            DROP TABLE IF EXISTS colaborador;

            CREATE TABLE colaborador (
              id           INTEGER PRIMARY KEY AUTOINCREMENT,
              nome         TEXT NOT NULL,
              email        TEXT NOT NULL,
              departamento TEXT NOT NULL,
              papel        TEXT NOT NULL DEFAULT 'colaborador'
            );

            CREATE TABLE equipamento (
              id        INTEGER PRIMARY KEY AUTOINCREMENT,
              nome      TEXT NOT NULL,
              categoria TEXT NOT NULL,
              valor     REAL NOT NULL
            );

            CREATE TABLE solicitacao (
              id             INTEGER PRIMARY KEY AUTOINCREMENT,
              colaborador_id INTEGER NOT NULL REFERENCES colaborador(id),
              equipamento_id INTEGER NOT NULL REFERENCES equipamento(id),
              justificativa  TEXT    NOT NULL,
              aberta_em      TEXT    NOT NULL,
              situacao       TEXT    NOT NULL DEFAULT 'aberta'
                CHECK (situacao IN ('aberta', 'aprovada', 'recusada', 'entregue', 'cancelada'))
            );

            -- Cada envio ou reenvio e uma tentativa. O texto nao muda depois de gravado.
            CREATE TABLE tentativa (
              id             INTEGER PRIMARY KEY AUTOINCREMENT,
              solicitacao_id INTEGER NOT NULL REFERENCES solicitacao(id),
              numero         INTEGER NOT NULL,
              justificativa  TEXT    NOT NULL,
              aberta_em      TEXT    NOT NULL,
              UNIQUE (solicitacao_id, numero)
            );

            -- Aprovacao ou recusa. Uma por tentativa, e sem UPDATE/DELETE.
            CREATE TABLE decisao (
              id           INTEGER PRIMARY KEY AUTOINCREMENT,
              tentativa_id INTEGER NOT NULL UNIQUE REFERENCES tentativa(id),
              decidido_por INTEGER NOT NULL REFERENCES colaborador(id),
              decidido_em  TEXT    NOT NULL,
              resultado    TEXT    NOT NULL CHECK (resultado IN ('aprovada', 'recusada'))
            );

            CREATE TABLE cancelamento (
              id             INTEGER PRIMARY KEY AUTOINCREMENT,
              solicitacao_id INTEGER NOT NULL UNIQUE REFERENCES solicitacao(id),
              cancelado_por  INTEGER NOT NULL REFERENCES colaborador(id),
              cancelado_em   TEXT    NOT NULL
            );

            CREATE TRIGGER tentativa_nao_altera
            BEFORE UPDATE ON tentativa
            BEGIN
              SELECT RAISE(ABORT, 'Tentativa registrada não pode ser alterada.');
            END;

            CREATE TRIGGER tentativa_nao_apaga
            BEFORE DELETE ON tentativa
            BEGIN
              SELECT RAISE(ABORT, 'Tentativa registrada não pode ser apagada.');
            END;

            CREATE TRIGGER decisao_nao_altera
            BEFORE UPDATE ON decisao
            BEGIN
              SELECT RAISE(ABORT, 'Decisão registrada não pode ser alterada.');
            END;

            CREATE TRIGGER decisao_nao_apaga
            BEFORE DELETE ON decisao
            BEGIN
              SELECT RAISE(ABORT, 'Decisão registrada não pode ser apagada.');
            END;

            CREATE TRIGGER cancelamento_nao_altera
            BEFORE UPDATE ON cancelamento
            BEGIN
              SELECT RAISE(ABORT, 'Cancelamento registrado não pode ser alterado.');
            END;

            CREATE TRIGGER cancelamento_nao_apaga
            BEFORE DELETE ON cancelamento
            BEGIN
              SELECT RAISE(ABORT, 'Cancelamento registrado não pode ser apagado.');
            END;

            CREATE TRIGGER solicitacao_cancelada_permanente
            BEFORE UPDATE OF situacao ON solicitacao
            WHEN OLD.situacao = 'cancelada' AND NEW.situacao <> 'cancelada'
            BEGIN
              SELECT RAISE(ABORT, 'Solicitação cancelada não volta a outra situação.');
            END;
            """;
        comando.ExecuteNonQuery();
    }

    public static int Executar(
        SqliteConnection conexao, SqliteTransaction? transacao, string sql, params (string Nome, object? Valor)[] parametros)
    {
        using var comando = conexao.CreateCommand();
        if (transacao is not null) comando.Transaction = transacao;
        comando.CommandText = sql;
        foreach (var (nome, valor) in parametros)
        {
            comando.Parameters.AddWithValue(nome, valor ?? DBNull.Value);
        }
        return comando.ExecuteNonQuery();
    }

    public static long UltimoId(SqliteConnection conexao, SqliteTransaction transacao)
    {
        using var comando = conexao.CreateCommand();
        comando.Transaction = transacao;
        comando.CommandText = "SELECT last_insert_rowid()";
        return (long)comando.ExecuteScalar()!;
    }

    public static List<Dictionary<string, object?>> BuscarTodos(
        SqliteConnection conexao, string sql, params (string Nome, object? Valor)[] parametros) =>
        BuscarTodos(conexao, null, sql, parametros);

    public static List<Dictionary<string, object?>> BuscarTodos(
        SqliteConnection conexao, SqliteTransaction? transacao, string sql, params (string Nome, object? Valor)[] parametros)
    {
        using var comando = conexao.CreateCommand();
        if (transacao is not null) comando.Transaction = transacao;
        comando.CommandText = sql;
        foreach (var (nome, valor) in parametros)
        {
            comando.Parameters.AddWithValue(nome, valor ?? DBNull.Value);
        }

        var linhas = new List<Dictionary<string, object?>>();
        using var leitor = comando.ExecuteReader();
        while (leitor.Read())
        {
            linhas.Add(Linha(leitor));
        }
        return linhas;
    }

    public static Dictionary<string, object?>? BuscarUm(
        SqliteConnection conexao, string sql, params (string Nome, object? Valor)[] parametros) =>
        BuscarUm(conexao, null, sql, parametros);

    public static Dictionary<string, object?>? BuscarUm(
        SqliteConnection conexao, SqliteTransaction? transacao, string sql, params (string Nome, object? Valor)[] parametros)
    {
        var linhas = BuscarTodos(conexao, transacao, sql, parametros);
        return linhas.Count == 0 ? null : linhas[0];
    }

    public static Dictionary<string, object?> Linha(SqliteDataReader leitor)
    {
        var linha = new Dictionary<string, object?>();
        for (var i = 0; i < leitor.FieldCount; i++)
        {
            linha[leitor.GetName(i)] = leitor.IsDBNull(i) ? null : leitor.GetValue(i);
        }
        return linha;
    }
}
