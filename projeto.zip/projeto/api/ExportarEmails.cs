// Gera a lista de e-mails para o comunicado de entrega de equipamentos,
// a partir do arquivo exportado pelo RH.
using System.Text.Json;

namespace Portal;

public static class ExportarEmails
{
    public static void Executar()
    {
        var dados = Path.GetFullPath(Path.Combine(Directory.GetCurrentDirectory(), "..", "dados"));
        var entrada = Path.Combine(dados, "colaboradores-rh.json");
        var saida = Path.Combine(dados, "emails-comunicado.json");

        using var documento = JsonDocument.Parse(File.ReadAllText(entrada));

        var emails = new List<string>();
        foreach (var colaborador in documento.RootElement.GetProperty("colaboradores").EnumerateArray())
        {
            if (colaborador.GetProperty("ativo").GetBoolean())
            {
                emails.Add(colaborador.GetProperty("email").GetString()!.ToLowerInvariant());
            }
        }

        var opcoes = new JsonSerializerOptions { WriteIndented = true };
        File.WriteAllText(saida, JsonSerializer.Serialize(new { emails }, opcoes) + "\n");

        Console.WriteLine($"{emails.Count} e-mails gravados em {saida}");
    }
}
