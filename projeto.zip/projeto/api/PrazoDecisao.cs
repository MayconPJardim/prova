using System.Globalization;

namespace Portal;

// Prazo de 8 horas uteis: segunda a sexta, 8h as 18h, sem os feriados informados.
// Expediente continuo, sem intervalo. 18h nao entra na contagem.
public static class PrazoDecisao
{
    public const string Formato = "yyyy-MM-dd'T'HH:mm:ss";

    static readonly TimeOnly Inicio = new(8, 0);
    static readonly TimeOnly Fim = new(18, 0);
    static readonly TimeSpan Duracao = TimeSpan.FromHours(8);

    static readonly HashSet<DateOnly> Feriados =
    [
        new(2026, 10, 12),
        new(2026, 11, 2),
        new(2026, 11, 15),
        new(2026, 11, 20),
        new(2026, 12, 25),
    ];

    public static DateTime Calcular(string abertaEm) =>
        Calcular(DateTime.ParseExact(abertaEm, Formato, CultureInfo.InvariantCulture));

    public static DateTime Calcular(DateTime abertaEm)
    {
        var cursor = ProximoInstanteUtil(abertaEm);
        var restante = Duracao;

        while (restante > TimeSpan.Zero)
        {
            var fimDoDia = DateOnly.FromDateTime(cursor).ToDateTime(Fim);
            var disponivel = fimDoDia - cursor;
            if (disponivel <= TimeSpan.Zero)
                throw new InvalidOperationException("Expediente sem tempo disponível.");

            if (disponivel >= restante)
                return cursor + restante;

            restante -= disponivel;
            cursor = ProximoInstanteUtil(fimDoDia);
        }

        return cursor;
    }

    public static string Formatar(DateTime instante) =>
        instante.ToString(Formato, CultureInfo.InvariantCulture);

    public static bool DiaUtil(DateOnly dia) =>
        dia.DayOfWeek is not (DayOfWeek.Saturday or DayOfWeek.Sunday)
        && !Feriados.Contains(dia);

    static DateTime ProximoInstanteUtil(DateTime instante)
    {
        var dia = DateOnly.FromDateTime(instante);
        if (DiaUtil(dia))
        {
            var inicio = dia.ToDateTime(Inicio);
            var fim = dia.ToDateTime(Fim);
            if (instante < inicio) return inicio;
            if (instante < fim) return instante;
        }

        do
        {
            dia = dia.AddDays(1);
        }
        while (!DiaUtil(dia));

        return dia.ToDateTime(Inicio);
    }

    public static void Verificar()
    {
        var segunda = new DateOnly(2026, 9, 7);
        while (segunda.DayOfWeek != DayOfWeek.Monday) segunda = segunda.AddDays(1);

        var terca = segunda.AddDays(1);
        var quarta = segunda.AddDays(2);
        var sexta = segunda.AddDays(4);
        var sabado = segunda.AddDays(5);
        var domingo = segunda.AddDays(6);
        var outraSegunda = segunda.AddDays(7);

        Conferir(segunda.ToDateTime(new TimeOnly(8, 0)), segunda.ToDateTime(new TimeOnly(16, 0)));
        Conferir(segunda.ToDateTime(new TimeOnly(9, 30)), segunda.ToDateTime(new TimeOnly(17, 30)));
        Conferir(segunda.ToDateTime(new TimeOnly(16, 0)), terca.ToDateTime(new TimeOnly(14, 0)));
        Conferir(segunda.ToDateTime(new TimeOnly(16, 30, 15)), terca.ToDateTime(new TimeOnly(14, 30, 15)));
        Conferir(quarta.ToDateTime(new TimeOnly(7, 15)), quarta.ToDateTime(new TimeOnly(16, 0)));
        Conferir(sexta.ToDateTime(new TimeOnly(17, 0)), outraSegunda.ToDateTime(new TimeOnly(15, 0)));
        Conferir(sexta.ToDateTime(new TimeOnly(18, 0)), outraSegunda.ToDateTime(new TimeOnly(16, 0)));
        Conferir(sabado.ToDateTime(new TimeOnly(12, 0)), outraSegunda.ToDateTime(new TimeOnly(16, 0)));
        Conferir(domingo.ToDateTime(new TimeOnly(23, 30)), outraSegunda.ToDateTime(new TimeOnly(16, 0)));

        // Quinta 24/09/2026 16:30, pedido em aberto do seed: sexta 25/09 14:30.
        Conferir(new DateTime(2026, 9, 24, 16, 30, 0), new DateTime(2026, 9, 25, 14, 30, 0));

        Conferir(new DateTime(2026, 10, 12, 10, 0, 0), new DateTime(2026, 10, 13, 16, 0, 0));
        Conferir(new DateTime(2026, 10, 9, 16, 0, 0), new DateTime(2026, 10, 13, 14, 0, 0));
        Conferir(new DateTime(2026, 11, 2, 9, 0, 0), new DateTime(2026, 11, 3, 16, 0, 0));
        Conferir(new DateTime(2026, 11, 19, 12, 0, 0), new DateTime(2026, 11, 23, 10, 0, 0));
        Conferir(new DateTime(2026, 11, 15, 11, 0, 0), new DateTime(2026, 11, 16, 16, 0, 0));
        Conferir(new DateTime(2026, 12, 25, 9, 0, 0), new DateTime(2026, 12, 28, 16, 0, 0));
    }

    static void Conferir(DateTime abertura, DateTime esperado)
    {
        var obtido = Calcular(abertura);
        if (obtido != esperado)
        {
            throw new InvalidOperationException(
                $"Prazo de {Formatar(abertura)}: obtido {Formatar(obtido)}, esperado {Formatar(esperado)}.");
        }
    }
}
