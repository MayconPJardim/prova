using System.Globalization;
using System.Text.Json;
using Microsoft.Data.Sqlite;
using Microsoft.Extensions.FileProviders;
using Portal;

if (args.Contains("seed"))
{
    Seed.Executar();
    return;
}
if (args.Contains("exportar-emails"))
{
    ExportarEmails.Executar();
    return;
}
if (args.Contains("verificar-prazo"))
{
    PrazoDecisao.Verificar();
    Console.WriteLine("Prazos conferidos.");
    return;
}

// Regras do portal (ver REGRAS.md). Quem tem este valor ou mais nao abre pedido.
const decimal LimiteDeResponsabilidade = 5500.00m;

var porta = Environment.GetEnvironmentVariable("PORT") ?? "3000";

var builder = WebApplication.CreateBuilder(args);
builder.WebHost.UseUrls($"http://localhost:{porta}");
var app = builder.Build();

var web = new PhysicalFileProvider(Path.GetFullPath(Path.Combine(Directory.GetCurrentDirectory(), "..", "web")));

app.UseExceptionHandler(erro => erro.Run(async contexto =>
{
    contexto.Response.StatusCode = 500;
    await contexto.Response.WriteAsJsonAsync(new { erro = "Erro interno." });
}));
app.UseDefaultFiles(new DefaultFilesOptions { FileProvider = web });
app.UseStaticFiles(new StaticFileOptions { FileProvider = web });

// Autenticacao simplificada para o exercicio: o id do usuario chega no
// cabecalho X-Usuario-Id. Nao ha senha e isso e proposital.
Dictionary<string, object?>? UsuarioAtual(HttpRequest requisicao, SqliteConnection conexao)
{
    if (!int.TryParse(requisicao.Headers["X-Usuario-Id"].ToString(), out var id)) return null;
    return Banco.BuscarUm(conexao, "SELECT * FROM colaborador WHERE id = $id", ("$id", id));
}

string AgoraIso() => DateTime.Now.ToString("yyyy-MM-dd'T'HH:mm:ss", CultureInfo.InvariantCulture);

// Soma o valor dos equipamentos ja entregues ao colaborador.
decimal ValorSobResponsabilidade(SqliteConnection conexao, long colaboradorId)
{
    using var comando = conexao.CreateCommand();
    comando.CommandText = """
        SELECT e.valor
          FROM solicitacao s
          JOIN equipamento e ON e.id = s.equipamento_id
         WHERE s.colaborador_id = $id AND s.situacao = 'entregue'
         ORDER BY s.id
        """;
    comando.Parameters.AddWithValue("$id", colaboradorId);

    decimal total = 0;
    using var itens = comando.ExecuteReader();
    while (itens.Read())
    {
        total += decimal.Parse(itens.GetDouble(0).ToString("0.00", CultureInfo.InvariantCulture), CultureInfo.InvariantCulture);
    }
    return total;
}

bool AtingiuLimite(SqliteConnection conexao, long colaboradorId) =>
    ValorSobResponsabilidade(conexao, colaboradorId) >= LimiteDeResponsabilidade;

IResult Erro(string mensagem, int status) => Results.Json(new { erro = mensagem }, statusCode: status);

// --- Rotas ----------------------------------------------------------------

app.MapGet("/api/colaboradores", () =>
{
    using var conexao = Banco.Conectar();
    return Results.Json(Banco.BuscarTodos(conexao, "SELECT id, nome, papel FROM colaborador ORDER BY nome"));
});

app.MapGet("/api/equipamentos", () =>
{
    using var conexao = Banco.Conectar();
    return Results.Json(Banco.BuscarTodos(conexao, "SELECT id, nome, categoria, valor FROM equipamento ORDER BY id"));
});

app.MapGet("/api/solicitacoes", (string? busca) =>
{
    busca = (busca ?? "").Trim();

    var sql = """
        SELECT s.id, e.nome AS equipamento, e.categoria, e.valor,
               c.id AS colaborador_id, c.nome AS colaborador_nome,
               s.justificativa, s.aberta_em, s.situacao,
               ca.cancelado_em, cc.nome AS cancelado_por_nome
          FROM solicitacao s
          JOIN equipamento e ON e.id = s.equipamento_id
          JOIN colaborador c ON c.id = s.colaborador_id
          LEFT JOIN cancelamento ca ON ca.solicitacao_id = s.id
          LEFT JOIN colaborador cc ON cc.id = ca.cancelado_por
        """;

    (string Nome, object? Valor)[] parametros = [];
    if (busca != "")
    {
        sql += " WHERE e.nome LIKE $busca ESCAPE '\\' OR c.nome LIKE $busca ESCAPE '\\'";
        parametros = [("$busca", PadraoBusca(busca))];
    }

    sql += " ORDER BY s.id";

    using var conexao = Banco.Conectar();
    var solicitacoes = Banco.BuscarTodos(conexao, sql, parametros);
    var tentativas = Banco.BuscarTodos(conexao, """
        SELECT t.solicitacao_id, t.numero, t.justificativa, t.aberta_em,
               d.resultado, d.decidido_em, dec.nome AS decidido_por_nome
          FROM tentativa t
          LEFT JOIN decisao d ON d.tentativa_id = t.id
          LEFT JOIN colaborador dec ON dec.id = d.decidido_por
         ORDER BY t.solicitacao_id, t.numero
        """);

    foreach (var solicitacao in solicitacoes)
    {
        var id = (long)solicitacao["id"]!;
        var historico = new List<Dictionary<string, object?>>();
        foreach (var tentativa in tentativas)
        {
            if ((long)tentativa["solicitacao_id"]! != id) continue;

            var decisoes = new List<Dictionary<string, object?>>();
            if (tentativa["resultado"] is string)
            {
                decisoes.Add(new Dictionary<string, object?>
                {
                    ["resultado"] = tentativa["resultado"],
                    ["decidido_em"] = tentativa["decidido_em"],
                    ["decidido_por_nome"] = tentativa["decidido_por_nome"],
                });
            }

            historico.Add(new Dictionary<string, object?>
            {
                ["numero"] = tentativa["numero"],
                ["justificativa"] = tentativa["justificativa"],
                ["aberta_em"] = tentativa["aberta_em"],
                ["decisoes"] = decisoes,
            });
        }

        solicitacao["tentativas"] = historico;
        solicitacao["prazo_limite"] = (string?)solicitacao["situacao"] == "aberta"
            ? PrazoDecisao.Formatar(PrazoDecisao.Calcular((string)solicitacao["aberta_em"]!))
            : null;
    }

    var patrimonio = new Dictionary<long, decimal>();
    foreach (var colaborador in Banco.BuscarTodos(conexao, "SELECT id FROM colaborador ORDER BY id"))
    {
        var id = (long)colaborador["id"]!;
        patrimonio[id] = ValorSobResponsabilidade(conexao, id);
    }

    return Results.Json(new { solicitacoes, patrimonio_por_colaborador = patrimonio });
});

// O colaborador abre uma solicitacao para si.
app.MapPost("/api/solicitacoes", async (HttpRequest requisicao) =>
{
    var corpo = await LerCorpo(requisicao);
    using var conexao = Banco.Conectar();

    var usuario = UsuarioAtual(requisicao, conexao);
    if (usuario is null) return Erro("Usuário não identificado.", 401);

    var justificativa = Justificativa(corpo);
    if (justificativa.Erro is not null) return justificativa.Erro;

    var equipamentoId = Inteiro(corpo, "equipamento_id");
    var bloqueio = BloqueioDeAbertura(conexao, (long)usuario["id"]!, equipamentoId);
    if (bloqueio is not null) return bloqueio;

    var abertaEm = AgoraIso();
    using var transacao = conexao.BeginTransaction();
    Banco.Executar(conexao, transacao, """
        INSERT INTO solicitacao (colaborador_id, equipamento_id, justificativa, aberta_em, situacao)
        VALUES ($colaborador, $equipamento, $justificativa, $abertaEm, 'aberta')
        """,
        ("$colaborador", usuario["id"]),
        ("$equipamento", equipamentoId),
        ("$justificativa", justificativa.Texto),
        ("$abertaEm", abertaEm));
    var novoId = Banco.UltimoId(conexao, transacao);
    Banco.Executar(conexao, transacao, """
        INSERT INTO tentativa (solicitacao_id, numero, justificativa, aberta_em)
        VALUES ($solicitacao, 1, $justificativa, $abertaEm)
        """,
        ("$solicitacao", novoId),
        ("$justificativa", justificativa.Texto),
        ("$abertaEm", abertaEm));
    transacao.Commit();

    return Results.Json(new { id = novoId }, statusCode: 201);
});

// A equipe tecnica aprova ou recusa.
app.MapPost("/api/solicitacoes/{id:int}/decisao", async (int id, HttpRequest requisicao) =>
{
    var corpo = await LerCorpo(requisicao);
    using var conexao = Banco.Conectar();

    var usuario = UsuarioAtual(requisicao, conexao);
    if (usuario is null) return Erro("Usuário não identificado.", 401);
    if ((string?)usuario["papel"] != "tecnico") return Erro("Somente a equipe técnica decide solicitações.", 403);

    var decisao = Texto(corpo, "decisao");
    if (decisao != "aprovada" && decisao != "recusada") return Erro("Decisão inválida.", 400);

    var solicitacao = Banco.BuscarUm(conexao, "SELECT * FROM solicitacao WHERE id = $id", ("$id", id));
    if (solicitacao is null) return Erro("Solicitação não encontrada.", 404);

    var tentativa = TentativaAtual(conexao, id);
    if (tentativa is null) return Erro("Solicitação sem tentativa registrada.", 409);

    using var transacao = conexao.BeginTransaction();
    var alteradas = Banco.Executar(conexao, transacao,
        "UPDATE solicitacao SET situacao = $situacao WHERE id = $id AND situacao = 'aberta'",
        ("$situacao", decisao),
        ("$id", id));
    if (alteradas != 1) return Erro("Solicitação não está aberta.", 409);

    Banco.Executar(conexao, transacao, """
        INSERT INTO decisao (tentativa_id, decidido_por, decidido_em, resultado)
        VALUES ($tentativa, $quem, $quando, $resultado)
        """,
        ("$tentativa", tentativa["id"]),
        ("$quem", usuario["id"]),
        ("$quando", AgoraIso()),
        ("$resultado", decisao));
    transacao.Commit();

    return Results.Json(new { ok = true });
});

// O colaborador reenvia uma solicitacao recusada, com nova justificativa.
app.MapPost("/api/solicitacoes/{id:int}/reenvio", async (int id, HttpRequest requisicao) =>
{
    var corpo = await LerCorpo(requisicao);
    using var conexao = Banco.Conectar();

    var usuario = UsuarioAtual(requisicao, conexao);
    if (usuario is null) return Erro("Usuário não identificado.", 401);

    var justificativa = Justificativa(corpo);
    if (justificativa.Erro is not null) return justificativa.Erro;

    var solicitacao = Banco.BuscarUm(conexao, "SELECT * FROM solicitacao WHERE id = $id", ("$id", id));
    if (solicitacao is null) return Erro("Solicitação não encontrada.", 404);
    if ((long)solicitacao["colaborador_id"]! != (long)usuario["id"]!)
        return Erro("Somente o colaborador que abriu a solicitação pode reenviá-la.", 403);
    if ((string?)solicitacao["situacao"] != "recusada")
        return Erro("Só é possível reenviar uma solicitação recusada.", 409);

    var bloqueio = BloqueioDeAbertura(conexao, (long)usuario["id"]!, Convert.ToInt32(solicitacao["equipamento_id"]));
    if (bloqueio is not null) return bloqueio;

    var atual = TentativaAtual(conexao, id);
    if (atual is null) return Erro("Solicitação sem tentativa registrada.", 409);

    var abertaEm = AgoraIso();
    var numero = (long)atual["numero"]! + 1;
    using var transacao = conexao.BeginTransaction();
    var alteradas = Banco.Executar(conexao, transacao, """
        UPDATE solicitacao
           SET justificativa = $justificativa, aberta_em = $abertaEm, situacao = 'aberta'
         WHERE id = $id AND situacao = 'recusada' AND colaborador_id = $colaborador
        """,
        ("$justificativa", justificativa.Texto),
        ("$abertaEm", abertaEm),
        ("$id", id),
        ("$colaborador", usuario["id"]));
    if (alteradas != 1) return Erro("Só é possível reenviar uma solicitação recusada.", 409);

    Banco.Executar(conexao, transacao, """
        INSERT INTO tentativa (solicitacao_id, numero, justificativa, aberta_em)
        VALUES ($solicitacao, $numero, $justificativa, $abertaEm)
        """,
        ("$solicitacao", id),
        ("$numero", numero),
        ("$justificativa", justificativa.Texto),
        ("$abertaEm", abertaEm));
    transacao.Commit();

    return Results.Json(new { ok = true });
});

// O colaborador cancela a propria solicitacao aberta ou aprovada.
app.MapPost("/api/solicitacoes/{id:int}/cancelamento", (int id, HttpRequest requisicao) =>
{
    using var conexao = Banco.Conectar();

    var usuario = UsuarioAtual(requisicao, conexao);
    if (usuario is null) return Erro("Usuário não identificado.", 401);

    var solicitacao = Banco.BuscarUm(conexao, "SELECT * FROM solicitacao WHERE id = $id", ("$id", id));
    if (solicitacao is null) return Erro("Solicitação não encontrada.", 404);
    if ((long)solicitacao["colaborador_id"]! != (long)usuario["id"]!)
        return Erro("Somente o colaborador que abriu a solicitação pode cancelá-la.", 403);

    var situacao = (string?)solicitacao["situacao"];
    if (situacao != "aberta" && situacao != "aprovada")
        return Erro("Só é possível cancelar uma solicitação aberta ou aprovada.", 409);

    using var transacao = conexao.BeginTransaction();
    var alteradas = Banco.Executar(conexao, transacao, """
        UPDATE solicitacao SET situacao = 'cancelada'
         WHERE id = $id AND colaborador_id = $colaborador AND situacao IN ('aberta', 'aprovada')
        """,
        ("$id", id),
        ("$colaborador", usuario["id"]));
    if (alteradas != 1) return Erro("Só é possível cancelar uma solicitação aberta ou aprovada.", 409);

    Banco.Executar(conexao, transacao, """
        INSERT INTO cancelamento (solicitacao_id, cancelado_por, cancelado_em)
        VALUES ($solicitacao, $quem, $quando)
        """,
        ("$solicitacao", id),
        ("$quem", usuario["id"]),
        ("$quando", AgoraIso()));
    transacao.Commit();

    return Results.Json(new { ok = true });
});

// A equipe tecnica registra a entrega do equipamento.
app.MapPost("/api/solicitacoes/{id:int}/entrega", (int id, HttpRequest requisicao) =>
{
    using var conexao = Banco.Conectar();

    var usuario = UsuarioAtual(requisicao, conexao);
    if (usuario is null) return Erro("Usuário não identificado.", 401);
    if ((string?)usuario["papel"] != "tecnico") return Erro("Somente a equipe técnica registra entregas.", 403);

    var solicitacao = Banco.BuscarUm(conexao, "SELECT * FROM solicitacao WHERE id = $id", ("$id", id));
    if (solicitacao is null) return Erro("Solicitação não encontrada.", 404);
    if ((string?)solicitacao["situacao"] != "aprovada") return Erro("Solicitação não está aprovada.", 409);

    using var atualizar = conexao.CreateCommand();
    atualizar.CommandText = "UPDATE solicitacao SET situacao = 'entregue' WHERE id = $id";
    atualizar.Parameters.AddWithValue("$id", id);
    atualizar.ExecuteNonQuery();

    return Results.Json(new { ok = true });
});

Console.WriteLine($"Portal de Solicitacao de Equipamentos em http://localhost:{porta}");
app.Run();

// --- Apoio ----------------------------------------------------------------

static async Task<JsonElement> LerCorpo(HttpRequest requisicao)
{
    try
    {
        using var documento = await JsonDocument.ParseAsync(requisicao.Body);
        return documento.RootElement.Clone();
    }
    catch (JsonException)
    {
        return default;
    }
}

static string PadraoBusca(string texto)
{
    var escapado = texto.Replace("\\", "\\\\").Replace("%", "\\%").Replace("_", "\\_");
    return "%" + escapado + "%";
}

(string? Texto, IResult? Erro) Justificativa(JsonElement corpo)
{
    var texto = (Texto(corpo, "justificativa") ?? "").Trim();
    if (texto.Length == 0) return (null, Erro("Informe a justificativa.", 400));
    if (texto.Length > 500) return (null, Erro("A justificativa deve ter no máximo 500 caracteres.", 400));
    return (texto, null);
}

IResult? BloqueioDeAbertura(SqliteConnection conexao, long colaboradorId, int? equipamentoId)
{
    var equipamento = Banco.BuscarUm(conexao, "SELECT id FROM equipamento WHERE id = $id", ("$id", equipamentoId));
    if (equipamento is null) return Erro("Equipamento não encontrado.", 404);
    if (AtingiuLimite(conexao, colaboradorId)) return Erro("Limite de responsabilidade atingido.", 409);
    return null;
}

static Dictionary<string, object?>? TentativaAtual(SqliteConnection conexao, long solicitacaoId) =>
    Banco.BuscarUm(conexao, """
        SELECT id, numero FROM tentativa
         WHERE solicitacao_id = $id
         ORDER BY numero DESC
         LIMIT 1
        """, ("$id", solicitacaoId));

static string? Texto(JsonElement corpo, string campo) =>
    corpo.ValueKind == JsonValueKind.Object &&
    corpo.TryGetProperty(campo, out var valor) &&
    valor.ValueKind == JsonValueKind.String
        ? valor.GetString()
        : null;

static int? Inteiro(JsonElement corpo, string campo) =>
    corpo.ValueKind == JsonValueKind.Object &&
    corpo.TryGetProperty(campo, out var valor) &&
    valor.ValueKind == JsonValueKind.Number &&
    valor.TryGetInt32(out var numero)
        ? numero
        : null;
