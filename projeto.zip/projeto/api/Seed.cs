namespace Portal;

public static class Seed
{
    static readonly (string Nome, string Email, string Departamento, string Papel)[] Colaboradores =
    [
        ("Ana Ribeiro",     "ana.ribeiro@empresa.example",    "Financeiro", "colaborador"),
        ("Carlos Tavares",  "carlos.tavares@empresa.example", "Comercial",  "colaborador"),
        ("Beatriz D'Avila", "beatriz.davila@empresa.example", "Marketing",  "colaborador"),
        ("Rui Marques",     "rui.marques@empresa.example",    "TI",         "tecnico"),
    ];

    static readonly (string Nome, string Categoria, double Valor)[] Equipamentos =
    [
        ("Notebook 14 polegadas",               "Computador", 4299.90),
        ("Notebook de engenharia 16 polegadas", "Computador", 7899.90),
        ("Monitor 24 polegadas",                "Monitor",    899.90),
        ("Hub USB-C 7 portas",                  "Acessório",  300.20),
        ("Headset com microfone",               "Acessório",  259.90),
        ("Webcam Full HD",                      "Acessório",  349.90),
        ("Teclado e mouse sem fio",             "Acessório",  229.90),
    ];

    // Decisoes do exemplo ficam no nome de Rui Marques (unico tecnico), para a tela
    // mostrar quem decidiu. Pedido em aberto nao tem decisao.
    const int TecnicoDoExemplo = 4;

    // colaborador, equipamento, justificativa, aberta em, situacao, decisao em, resultado
    static readonly (int Colaborador, int Equipamento, string Justificativa, string AbertaEm, string Situacao, string? DecididoEm, string? Resultado)[] Solicitacoes =
    [
        (1, 1, "Substituir notebook com bateria danificada",   "2026-08-03T09:15:00", "entregue", "2026-08-03T11:00:00", "aprovada"),
        (1, 3, "Segundo monitor para conciliação bancária",     "2026-08-10T14:02:00", "entregue", "2026-08-10T15:10:00", "aprovada"),
        (1, 4, "Conectar monitor e teclado ao notebook novo",   "2026-08-10T14:05:00", "entregue", "2026-08-10T15:12:00", "aprovada"),
        (2, 2, "Rodar simulações de propostas comerciais",      "2026-07-20T10:40:00", "entregue", "2026-07-20T14:00:00", "aprovada"),
        (2, 5, "Reuniões com clientes por vídeo",               "2026-09-15T11:20:00", "recusada", "2026-09-15T15:40:00", "recusada"),
        (3, 5, "Headset atual com o microfone falhando",        "2026-09-01T08:50:00", "entregue", "2026-09-01T10:05:00", "aprovada"),
        (3, 6, "Gravação de vídeos para a campanha de outubro", "2026-09-24T16:30:00", "aberta",   null,                   null),
        (3, 7, "Teclado com teclas falhando",                   "2026-09-25T09:05:00", "aprovada", "2026-09-25T10:30:00", "aprovada"),
    ];

    public static void Executar()
    {
        using var conexao = Banco.Conectar();
        using var transacao = conexao.BeginTransaction();

        Banco.CriarEsquema(conexao, transacao);

        foreach (var c in Colaboradores)
        {
            Banco.Executar(conexao, transacao,
                "INSERT INTO colaborador (nome, email, departamento, papel) VALUES ($nome, $email, $departamento, $papel)",
                ("$nome", c.Nome),
                ("$email", c.Email),
                ("$departamento", c.Departamento),
                ("$papel", c.Papel));
        }

        foreach (var e in Equipamentos)
        {
            Banco.Executar(conexao, transacao,
                "INSERT INTO equipamento (nome, categoria, valor) VALUES ($nome, $categoria, $valor)",
                ("$nome", e.Nome),
                ("$categoria", e.Categoria),
                ("$valor", e.Valor));
        }

        foreach (var s in Solicitacoes)
        {
            Banco.Executar(conexao, transacao, """
                INSERT INTO solicitacao (colaborador_id, equipamento_id, justificativa, aberta_em, situacao)
                VALUES ($colaborador, $equipamento, $justificativa, $abertaEm, $situacao)
                """,
                ("$colaborador", s.Colaborador),
                ("$equipamento", s.Equipamento),
                ("$justificativa", s.Justificativa),
                ("$abertaEm", s.AbertaEm),
                ("$situacao", s.Situacao));

            var solicitacaoId = Banco.UltimoId(conexao, transacao);
            Banco.Executar(conexao, transacao, """
                INSERT INTO tentativa (solicitacao_id, numero, justificativa, aberta_em)
                VALUES ($solicitacao, 1, $justificativa, $abertaEm)
                """,
                ("$solicitacao", solicitacaoId),
                ("$justificativa", s.Justificativa),
                ("$abertaEm", s.AbertaEm));

            if (s.DecididoEm is not null && s.Resultado is not null)
            {
                var tentativaId = Banco.UltimoId(conexao, transacao);
                Banco.Executar(conexao, transacao, """
                    INSERT INTO decisao (tentativa_id, decidido_por, decidido_em, resultado)
                    VALUES ($tentativa, $quem, $quando, $resultado)
                    """,
                    ("$tentativa", tentativaId),
                    ("$quem", TecnicoDoExemplo),
                    ("$quando", s.DecididoEm),
                    ("$resultado", s.Resultado));
            }
        }

        transacao.Commit();

        Console.WriteLine($"Banco recriado em {Banco.Arquivo}");
        Console.WriteLine($"{Colaboradores.Length} colaboradores, {Equipamentos.Length} equipamentos, " +
                          $"{Solicitacoes.Length} solicitacoes.");
    }
}
