# nuget-offline

Repositorio local de pacotes NuGet, para o projeto restaurar e compilar **sem internet**
e sem depender do cache do usuario do Windows.

Sao os pacotes exigidos por `Portal.csproj` e suas dependencias (Microsoft.Data.Sqlite
10.0.12 e SQLitePCLRaw 2.1.12), obtidos de nuget.org em 29/09/2026.
Nao e um material para o candidato editar.
