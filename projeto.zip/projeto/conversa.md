# Validation implementation guidelines
_Exported on 9/30/2026 at 15:49:23 GMT-3 from Cursor (3.19.7)_

---

**User**

@01B-PRATICA.md (114-124) precisa implementar essas validações seguindo as boas praticas de engenharia de software e seguindo o arquivo @REGRAS.md 

---

**Cursor**

Vou ler as regras do projeto e o trecho da prática para implementar essas validações no código existente.

O enunciado pede cinco regras de decisão, reenvio, prazo, cancelamento e imutabilidade. Vou mapear a API e a tela atuais antes de alterar o código.

As cinco regras pedem histórico imutável, reenvio, prazo em horas úteis, cancelamento e registro de quem decidiu. Vou encaixar isso no modelo atual sem perder as regras de negócio do portal.

A regra de abertura e o registro da decisão passam a valer no servidor, com histórico que não se apaga. Em seguida ajusto a tela para mostrar prazo, tentativas e cancelamento.

O servidor antigo ainda está com o executável aberto. Vou encerrá-lo, compilar de novo e recriar o banco com o novo esquema.

---

**User**

ok, agora gostaria de um review para validar a aderencia do codigo com as regras e com oq foi solicitado

---

**Cursor**

Vou confrontar o código atual com `REGRAS.md` e com os cinco pedidos da prática, ponto a ponto.

Os cinco pedidos da prática estão implementados e batem com as regras 1 a 8 e 10. A regra 9 continua fora do código. O prazo da solicitação em aberto no banco atual é 25/09/2026 14:30.

## Os cinco pedidos

| Pedido | Situação | Onde se vê |
|---|---|---|
| 1. Quem decidiu e quando | Atende | Tabela `decisao` (`decidido_por`, `decidido_em`). A coluna "Tentativas e decisões" mostra nome e data/hora. |
| 2. Reenvio de recusada, com as regras de uma solicitação nova, e histórico na tela | Atende | `POST /api/solicitacoes/{id}/reenvio`. Exige dono, justificativa, item do catálogo e limite de R$ 5.500,00. Cada reenvio grava outra tentativa; a tela lista todas, com a decisão de cada uma. |
| 3. Prazo de 8 horas úteis, segunda a sexta, 8h–18h, sem os feriados listados | Atende | `PrazoDecisao`. A coluna "Prazo" só aparece em solicitação `aberta`. No seed, a webcam aberta em 24/09/2026 16:30 tem prazo `2026-09-25T14:30:00`. |
| 4. Cancelar a qualquer momento, inclusive depois de aprovada | Atende no que o enunciado explicita | Dono cancela `aberta` ou `aprovada`. A decisão de aprovação permanece no histórico. |
| 5. Decisão registrada não se altera nem se apaga | Atende | Não há rota de edição. Gatilhos abortam `UPDATE` e `DELETE` em `decisao`. Há no máximo uma decisão por tentativa. |

## Regras do portal

- **1 e 2.** Abertura e reenvio só aceitam equipamento que existe no catálogo, sempre para o usuário do cabeçalho `X-Usuario-Id`, com justificativa obrigatória.
- **3.** Só papel `tecnico` aprova ou recusa.
- **4 e 5.** Só `tecnico` registra entrega, e só de solicitação `aprovada`. O equipamento entregue continua com quem abriu o pedido.
- **6 e 7.** O patrimônio soma só situação `entregue`. Com R$ 5.500,00 ou mais, a abertura e o reenvio respondem 409. No banco atual: Ana R$ 5.500,00, Carlos R$ 7.899,90, Beatriz R$ 259,90.
- **8.** A busca filtra por nome do equipamento ou do colaborador, com parâmetro (o texto não entra mais direto no SQL).
- **9.** Ainda não atende. `ExportarEmails` inclui todo colaborador ativo e ignora `aceita_comunicados`. Carlos e Lia entrariam na lista mesmo sem aceite. Isso já estava assim e não faz parte dos cinco pedidos.
- **10.** Continua valendo o cabeçalho `X-Usuario-Id` e o seletor "Entrar como".

## Premissas que o enunciado não fecha

Vale registrar em `RESPOSTAS.md`, porque a seção da Tarefa 2 ainda está no modelo em branco.

- Expediente contínuo, das 8h inclusive até as 18h exclusive. Pedido às 18h, de madrugada ou no fim de semana começa a contar no próximo instante útil. Sem intervalo de almoço.
- Feriados considerados: só 12/10, 02/11, 15/11, 20/11 e 25/12 de 2026. O 15/11 cai num domingo; o dia já fica de fora por ser fim de semana.
- O prazo é da solicitação `aberta` (aguardando decisão). Aprovada, recusada, entregue e cancelada não mostram prazo. No reenvio, as 8 horas recomeçam na nova abertura.
- Cancelamento para em entregue e em recusada. Entregue já passou a responsabilidade (regras 5 e 6); recusada segue pelo reenvio. O texto pede cancelamento inclusive depois de aprovada, e isso está coberto.
- As decisões do seed que já vinham aprovadas, recusadas ou entregues foram atribuídas a Rui Marques, o único técnico, com horários fixos no `Seed`. Sem isso a tela não teria quem e quando nesses pedidos antigos.

