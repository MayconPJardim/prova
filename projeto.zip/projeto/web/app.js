let usuarios = [];
let usuarioAtual = null;

const elUsuario     = document.getElementById('usuario');
const elEquipamento = document.getElementById('equipamento');
const elJustificativa = document.getElementById('justificativa');
const elForm        = document.getElementById('form-solicitacao');
const elBusca       = document.getElementById('busca');
const elCorpo       = document.getElementById('corpo');
const elMensagem    = document.getElementById('mensagem');
const elAviso       = document.getElementById('aviso-patrimonio');

const ROTULOS = {
  aberta: 'Aberta',
  aprovada: 'Aprovada',
  recusada: 'Recusada',
  entregue: 'Entregue',
  cancelada: 'Cancelada',
};

function dinheiro(valor) {
  return 'R$ ' + valor.toFixed(2).replace('.', ',').replace(/\B(?=(\d{3})+(?!\d))/g, '.');
}

function dataHoraBR(iso) {
  if (!iso) return '';
  const [data, hora] = iso.split('T');
  const [ano, mes, dia] = data.split('-');
  return dia + '/' + mes + '/' + ano + ' ' + hora.slice(0, 5);
}

function agoraIsoLocal() {
  const agora = new Date();
  const p = (n) => String(n).padStart(2, '0');
  return agora.getFullYear() + '-' + p(agora.getMonth() + 1) + '-' + p(agora.getDate()) +
    'T' + p(agora.getHours()) + ':' + p(agora.getMinutes()) + ':' + p(agora.getSeconds());
}

function escapar(texto) {
  return String(texto ?? '')
    .replace(/&/g, '&amp;')
    .replace(/</g, '&lt;')
    .replace(/>/g, '&gt;')
    .replace(/"/g, '&quot;');
}

function mostrar(texto, erro) {
  elMensagem.textContent = texto || '';
  elMensagem.className = 'mensagem' + (erro ? ' erro' : '');
}

async function api(caminho, opcoes) {
  const config = Object.assign({ headers: {} }, opcoes);
  config.headers['Content-Type'] = 'application/json';
  if (usuarioAtual) config.headers['X-Usuario-Id'] = String(usuarioAtual.id);

  const resposta = await fetch(caminho, config);
  const corpo = await resposta.json().catch(() => ({}));
  if (!resposta.ok) throw new Error(corpo.erro || 'Falha na requisição.');
  return corpo;
}

async function carregarUsuarios() {
  usuarios = await api('/api/colaboradores');
  elUsuario.innerHTML = usuarios
    .map((u) => '<option value="' + u.id + '">' + u.nome + ' (' + u.papel + ')</option>')
    .join('');
  usuarioAtual = usuarios[0];
  elUsuario.value = usuarioAtual.id;
}

async function carregarCatalogo() {
  const equipamentos = await api('/api/equipamentos');
  elEquipamento.innerHTML = equipamentos
    .map((e) => '<option value="' + e.id + '">' + e.nome + ' — ' + dinheiro(e.valor) + '</option>')
    .join('');
}

function acoes(solicitacao) {
  const botoes = [];
  const minha = Number(solicitacao.colaborador_id) === Number(usuarioAtual.id);

  if (usuarioAtual.papel === 'tecnico' && solicitacao.situacao === 'aberta') {
    botoes.push(
      '<button type="button" class="acao" data-decidir="' + solicitacao.id + '" data-decisao="aprovada">Aprovar</button>' +
      '<button type="button" class="acao" data-decidir="' + solicitacao.id + '" data-decisao="recusada">Recusar</button>'
    );
  }
  if (usuarioAtual.papel === 'tecnico' && solicitacao.situacao === 'aprovada') {
    botoes.push('<button type="button" class="acao" data-entregar="' + solicitacao.id + '">Registrar entrega</button>');
  }
  if (minha && (solicitacao.situacao === 'aberta' || solicitacao.situacao === 'aprovada')) {
    botoes.push('<button type="button" class="acao" data-cancelar="' + solicitacao.id + '">Cancelar</button>');
  }
  if (minha && solicitacao.situacao === 'recusada') {
    botoes.push(
      '<form class="reenvio" data-reenvio="' + solicitacao.id + '">' +
      '<textarea required maxlength="500" placeholder="Nova justificativa"></textarea>' +
      '<button type="submit">Reenviar</button>' +
      '</form>'
    );
  }
  return botoes.length ? botoes.join('') : '—';
}

function situacao(s) {
  let texto = ROTULOS[s.situacao] || escapar(s.situacao);
  if (s.situacao === 'cancelada' && s.cancelado_por_nome) {
    texto += '<br><small>por ' + escapar(s.cancelado_por_nome) + ' em ' + dataHoraBR(s.cancelado_em) + '</small>';
  }
  return texto;
}

function prazo(s) {
  if (s.situacao !== 'aberta' || !s.prazo_limite) return '—';
  const vencido = s.prazo_limite < agoraIsoLocal();
  return '<span class="' + (vencido ? 'vencido' : '') + '">' + dataHoraBR(s.prazo_limite) +
    (vencido ? '<br><small>vencido</small>' : '') + '</span>';
}

function historico(s) {
  const tentativas = s.tentativas || [];
  if (tentativas.length === 0) return '—';

  return '<ol class="historico">' + tentativas.map((t) => {
    const decisoes = t.decisoes || [];
    const textoDecisao = decisoes.length
      ? decisoes.map((d) => (ROTULOS[d.resultado] || escapar(d.resultado)) +
          ' por ' + escapar(d.decidido_por_nome) + ' em ' + dataHoraBR(d.decidido_em)).join('<br>')
      : 'sem decisão';
    return '<li><strong>Tentativa ' + escapar(t.numero) + '</strong> — ' + dataHoraBR(t.aberta_em) +
      '<br>' + escapar(t.justificativa) +
      '<br><small>' + textoDecisao + '</small></li>';
  }).join('') + '</ol>';
}

function linha(s) {
  return '<tr>' +
    '<td>' + escapar(s.equipamento) + '<br><small>' + escapar(s.categoria) + '</small></td>' +
    '<td>' + escapar(s.colaborador_nome) + '</td>' +
    '<td class="num">' + dinheiro(s.valor) + '</td>' +
    '<td>' + escapar(s.justificativa) + '</td>' +
    '<td class="quando">' + dataHoraBR(s.aberta_em) + '</td>' +
    '<td class="quando">' + prazo(s) + '</td>' +
    '<td>' + situacao(s) + '</td>' +
    '<td>' + historico(s) + '</td>' +
    '<td>' + acoes(s) + '</td>' +
    '</tr>';
}

async function carregarSolicitacoes() {
  const busca = elBusca.value.trim();
  const dados = await api('/api/solicitacoes?busca=' + encodeURIComponent(busca));

  elCorpo.innerHTML = dados.solicitacoes.map(linha).join('');

  const meuPatrimonio = dados.patrimonio_por_colaborador[usuarioAtual.id] || 0;
  elAviso.textContent = meuPatrimonio > 0
    ? 'Valor sob sua responsabilidade: ' + dinheiro(meuPatrimonio)
    : '';
}

elUsuario.addEventListener('change', () => {
  usuarioAtual = usuarios.find((u) => u.id === Number(elUsuario.value));
  mostrar('');
  carregarSolicitacoes().catch((e) => mostrar(e.message, true));
});

elForm.addEventListener('submit', async (evento) => {
  evento.preventDefault();
  try {
    await api('/api/solicitacoes', {
      method: 'POST',
      body: JSON.stringify({
        equipamento_id: Number(elEquipamento.value),
        justificativa: elJustificativa.value,
      }),
    });
    elJustificativa.value = '';
    mostrar('Solicitação enviada.');
    await carregarSolicitacoes();
  } catch (erro) {
    mostrar(erro.message, true);
  }
});

document.getElementById('btn-buscar').addEventListener('click', () => {
  carregarSolicitacoes().catch((e) => mostrar(e.message, true));
});

elBusca.addEventListener('keydown', (evento) => {
  if (evento.key === 'Enter') carregarSolicitacoes().catch((e) => mostrar(e.message, true));
});

elCorpo.addEventListener('click', async (evento) => {
  const botao = evento.target.closest('button');
  if (!botao || botao.closest('form.reenvio')) return;

  try {
    if (botao.dataset.decidir) {
      await api('/api/solicitacoes/' + botao.dataset.decidir + '/decisao', {
        method: 'POST',
        body: JSON.stringify({ decisao: botao.dataset.decisao }),
      });
      mostrar('Solicitação ' + botao.dataset.decisao + '.');
    } else if (botao.dataset.entregar) {
      await api('/api/solicitacoes/' + botao.dataset.entregar + '/entrega', { method: 'POST' });
      mostrar('Entrega registrada.');
    } else if (botao.dataset.cancelar) {
      if (!window.confirm('Cancelar esta solicitação?')) return;
      await api('/api/solicitacoes/' + botao.dataset.cancelar + '/cancelamento', { method: 'POST' });
      mostrar('Solicitação cancelada.');
    }
    await carregarSolicitacoes();
  } catch (erro) {
    mostrar(erro.message, true);
  }
});

elCorpo.addEventListener('submit', async (evento) => {
  const form = evento.target.closest('form.reenvio');
  if (!form) return;
  evento.preventDefault();

  const justificativa = form.querySelector('textarea').value;
  try {
    await api('/api/solicitacoes/' + form.dataset.reenvio + '/reenvio', {
      method: 'POST',
      body: JSON.stringify({ justificativa: justificativa }),
    });
    mostrar('Solicitação reenviada.');
    await carregarSolicitacoes();
  } catch (erro) {
    mostrar(erro.message, true);
  }
});

carregarUsuarios()
  .then(carregarCatalogo)
  .then(carregarSolicitacoes)
  .catch((erro) => mostrar(erro.message, true));
